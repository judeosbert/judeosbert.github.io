/**
 * Created by Jude Osbert K on 22-03-2016.
 */
jQuery(document).ready(function($) {
    $('.counter').counterUp({
        delay: 20,
        time: 1000
    });
});